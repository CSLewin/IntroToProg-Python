# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Craig Lewin, 04/26/2019, Began coding for assignment 5
#   Craig Lewin, 04/27/2019, Continued to add code for assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --# declare variables and constants
objFileName = open("ToDo.txt", "r")  # Just opening the file for "r"eading for now. We're not writing to it yet.
strData = ""  # A row of text data from the file
lstTable = []  # A master list acting as a 'table' of rows
# strMenu = A menu of user options
strMenu = """  
    Menu of Options
    1) DISPLAY current data
    2) ADD a new item.
    3) REMOVE an existing item.
    4) SAVE data to a text file
    5) EXIT this program
    """
strChoice = ""  # Capture the user option selection. Initialized here to make sure it starts out empty.

# -- Processing --#
# Step 1 - # At launch, iteratively load rows from the txt into a dict and then place each dict into a master list.

for row in objFileName:  # Perform this loop for each row in the text file.
    dicTable = {}  # Initialize an empty dict. We're about to fill it, and we want it to be empty at each loop's start.
    dicTable["Task"] = row.split(",")[0].rstrip()  # Create k/v pair of "Task" : [1st index of row as split by ","]
    dicTable["Priority"] = row.split(",")[1].rstrip()  # Create k/v pair of "Priority" : [2nd index of row as split by ","]
    # The .rstrip() bits are to remove newlines in the text file. This will be important when saving it later.
    lstTable.append(dicTable)  # Add the dict "dicTable" to the master list "lstTable"

objFileName.close()  # Close the file; we're doing script data stuff now. If we want to write, we'll open it later.

# Step 2 - # Display a menu of choices to the user
while True:
    print(strMenu)  # Print the main menu! This is defined at the top of the script.
    strChoice = str(input("Which option would you like to perform? [1 to 4, or 5 to exit]: "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        for row in lstTable:  # For each item in the master list...
            print(str(row))  # ...print it out as a string.
        continue  # Since True is still True, show the user the menu again.

    # Step 4 - Add a new item to the master list
    elif strChoice.strip() == '2':
        task = input("Write the name of the task: ")
        priority = input("Write the task's priority (low/high): ")
        lstTable.append({"Task" : task, "Priority" : priority})  # Append a new dict literal to the master list.
        continue  # Since True is still True, show the user the menu again.

    # Step 5 - Remove an item from the master list
    elif strChoice == '3':
        print("Your current data is:\n")
        counter = 1  # Initialize a counter for displaying the rows of data to the user.
        for row in lstTable:  # Loop through each row of data...
            print((str(counter)) + ": " + str(row))  # ...by printing the counter number and the row as strings...
            counter += 1  # ...and then increase the counter number by one.
        cutItem = int(input("\nEnter the row number you wish to permanently delete (or '0' to delete nothing): "))
        if cutItem == 0:
            continue  # Don't delete anything if the user inputs "0".
        else:
            del lstTable[cutItem - 1]  # Delete the selected row. It's 0-indexed, so subtract 1 from the user's input.
        continue  # Since True is still True, show the user the menu again.

    # Step 6 - Save tasks to the ToDo.txt file
    elif strChoice == '4':
        # Give the user a chance to back out of saving and return to the main menu.
        if input("Type 'y' to REPLACE ALL DATA in ToDo.txt with your current data."
                 "\nType anything else to return to the menu: ").lower() == "y":
            objFileName = open("ToDo.txt", "w")  # THIS DELETES EVERYTHING IN TODO.TXT. BE CAREFUL WITH "w" MODE.
            for row in lstTable:  # For each row (dict) in the master list...
                objFileName.write(str(row['Task'] + "," + row['Priority'] + "\n"))  # Write these values to the .txt.
            objFileName.close()  # Always close your file when you're done.
            print("\nAll data has been appended to ToDo.txt. Returning to main menu.")  # Let the user know what's up
        else:
            print("\nData has NOT been saved. Returning to main menu.")  # Let the user know what's up
        continue  # Since True is still True, show the user the menu again.

    # Step 7 - Exit program
    elif strChoice == '5':
        print("Goodbye!")
        break  # Break the loop and Exit the program.
