# -------------------------------------------------#
# Title: Exception Handler Example Script
# Dev:   Craig Lewin
# Date:  May 10, 2019
# ChangeLog: (Who, When, What)
#   Craig Lewin, 05/10/2019, Began coding for assignment 7
# -------------------------------------------------#

try:
    print("Hey there. You're going to give me bad data and I'm going to handle it elegantly.")
    number = int(input("Give me literally ANY data but an integer: "))
except Exception as e:
    print("\nCONGRATULATIONS!!! You broke the script. \n\nHere's the error: \n\t" + str(e))
else:
    print("\n\nI guess you just wanted to get along. You gave me " + str(number) + ", which is probably an integer.")

try:
    print("\n\nLet's try another one.")
    divide = input("Dividing by zero is bad. Give me a number to divide 10 by: ")
    y = 10 / float(divide)
except ZeroDivisionError as e:
    print("YOU DIVIDED BY ZERO!!!! NOOOO!!!!")
except Exception as e:
    print("\nYou broke the script AGAIN! But you didn't divide by zero--I have an exception handler line for that.")
    print("\nHere's the error: \n\t" + str(e))
else:
    print("\n\nYou're pretty agreeable. Incidentally, 10 / " + divide + " = " + str(y))
finally:
    print("\n\nEnd of the line. Thanks for playing!")

input("Press Enter to exit.")