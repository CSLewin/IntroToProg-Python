# -------------------------------------------------#
# Title: Pickling and Unpickling Data Example Script
# Dev:   Craig Lewin
# Date:  May 10, 2019
# ChangeLog: (Who, When, What)
#   Craig Lewin, 05/10/2019, Began coding for assignment 7
# -------------------------------------------------#

import pickle

# Create a list
print("You're going to tell me how you feel about eating fruit.")

id = int(input("Enter a numeric ID: "))
fruit = str(input("Enter a type of fruit: "))
emotion = str(input("Enter the emotion that eating this fruit evokes in you: "))

lstFruitFeelings = [id, fruit, emotion]
print("You provided: " + str(lstFruitFeelings))

#Pickle the list using the pickle.dump method
objFile = open("FruitFeelings.pkl", "ab")
pickle.dump(lstFruitFeelings, objFile)  # Dump the contents of lstFruitFeelings into the file objFile
objFile.close()
print("\nThis script has now dumped your fruit feelings into a pickled format.")

#Write the data to a text file to manually check it later
objFile = open("FruitFeelingsCONFIRM.txt", "a")
objFile.write(str(lstFruitFeelings) + "\n")
objFile.close()
print("\nThe script also saved your data to a plaintext file for manual verification.")

#Unpickle the data file using the pickle.load method
print("\nNow we'll unpickle your fruit feelings into a format this script can spit out again.")
objFile = open("FruitFeelings.pkl", "rb")
objFileData = pickle.load(objFile) #Note that load() only loads one row of data.
objFile.close()

print("This is the FIRST LINE of the data that we have now unpickled: \n")
print(objFileData)
print("This is a bad way to display data, though; pickling should be used for complex serialized data, generally.")

print("\n\n(If you want to step through every line of your data...")
print("...you probably don't want to use pickle.load() directly.)")
print("\nUse a for-loop. Like this: ")
objFile = open("FruitFeelingsCONFIRM.txt", "r")
for line in objFile:
    print(line)

input("Press Enter to exit.")