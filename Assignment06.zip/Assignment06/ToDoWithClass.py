# -------------------------------------------------#
# Title: Rearranging ToDo.py to use Classes
# Dev:   Craig Lewin
# Date:  May 6, 2019
# ChangeLog: (Who, When, What)
#   Craig Lewin, 05/06/2019, Began coding for assignment 6
# -------------------------------------------------#

# -- Data --# declare variables and constants
objFileName = open("ToDo.txt", "r")  # Just opening the file for "r"eading for now. We're not writing to it yet.
strData = ""  # A row of text data from the file
lstTable = []  # A master list acting as a 'table' of rows
strMenu = """  
    Menu of Options
    1) DISPLAY current data
    2) ADD a new item.
    3) REMOVE an existing item.
    4) SAVE data to a text file
    5) EXIT this program
    """
strChoice = ""  # Capture the user option selection. Initialized here to make sure it starts out empty.


class ToDoList(object):
    """Class containing common ToDo list functions."""

    def LoadData(file):
        """"Iteratively load rows from a txt into a dict and then place each dict into a master list."""
        for row in file:  # Perform this loop for each row in the text file.
            dicTable = {}  # Initialize an empty dict. Empty it at the start of each loop.
            dicTable["Task"] = row.split(",")[0].rstrip()
            dicTable["Priority"] = row.split(",")[1].rstrip()
            # The .rstrip() bits are to remove newlines in the text file. This will be important when saving it later.
            lstTable.append(dicTable)  # Add the dict "dicTable" to the master list "lstTable"
        objFileName.close()

    def DisplayList(list):
        """"Show the current items in the table."""
        for row in list:
            print(str(row))

    def AddTask(list):
        """Add a new item to the master list"""
        task = input("Write the name of the task: ")
        priority = input("Write the task's priority (low/high): ")
        list.append({"Task": task, "Priority": priority})  # Append a new dict literal to the master list.

    def RemoveTask(list):
        """Remove a task from the master list"""
        print("Your current data is:\n")
        counter = 1  # Initialize a counter for displaying the rows of data to the user.
        for row in list:  # Loop through each row of data...
            print((str(counter)) + ": " + str(row))  # ...by printing the counter number and the row as strings...
            counter += 1  # ...and then increase the counter number by one.
        cutItem = int(input("\nEnter the row number you wish to permanently delete (or '0' to delete nothing): "))
        if cutItem != 0:  #  We don't actually need to do anything but continue if cutItem IS zero.
            del lstTable[cutItem - 1]  # Delete the selected row. It's 0-indexed, so subtract 1 from the user's input.

    def SaveDataToFile(file, list):
        """Save tasks to the ToDo.txt file"""
        # Give the user a chance to back out of saving and return to the main menu.
        if input("Type 'y' to REPLACE ALL DATA in ToDo.txt with your current data."
                 "\nType anything else to return to the menu: ").lower() == "y":
            file = open("ToDo.txt", "w")  # THIS DELETES EVERYTHING IN TODO.TXT. BE CAREFUL WITH "w" MODE.
            for row in list:  # For each row (dict) in the master list...
                file.write(str(row['Task'] + "," + row['Priority'] + "\n"))  # ...write these values to the .txt.
            file.close()
            print("\nAll data has been appended to ToDo.txt. Returning to main menu.")
        else:
            print("\nData has NOT been saved. Returning to main menu.")


# -- Processing --#
# Step 1 - # At launch, iteratively load rows from the txt into a dict and then place each dict into a master list.
ToDoList.LoadData(objFileName)

# Step 2 - # Display a menu of choices to the user
while True:
    print(strMenu)  # Print the main menu! This is defined at the top of the script.
    strChoice = str(input("Which option would you like to perform? [1 to 4, or 5 to exit]: "))
    print()  # adding a new line for readability

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        ToDoList.DisplayList(lstTable)
        continue

    # Step 4 - Add a new item to the master list
    elif strChoice.strip() == '2':
        ToDoList.AddTask(lstTable)
        continue

    # Step 5 - Remove an item from the master list
    elif strChoice == '3':
        ToDoList.RemoveTask(lstTable)
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif strChoice == '4':
        ToDoList.SaveDataToFile(objFileName, lstTable)
        continue

    # Step 7 - Exit program
    elif strChoice == '5':
        print("Goodbye!")
        break  # Break the loop and Exit the program.
